package online.dailyq.api.response

data class HelloWorld(val date: String, val message: String)
