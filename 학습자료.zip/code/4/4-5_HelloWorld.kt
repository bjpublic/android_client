package online.dailyq.api.response

import java.util.*

data class HelloWorld(val date: Date, val message: String)
