package online.dailyq.api

enum class AuthType {
    NO_AUTH, ACCESS_TOKEN
}
