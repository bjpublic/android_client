package online.dailyq.api.response

data class AuthToken(val accessToken: String, val refreshToken: String)
