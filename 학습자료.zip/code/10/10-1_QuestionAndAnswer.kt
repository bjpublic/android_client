package online.dailyq.api.response

data class QuestionAndAnswer(
    val question: Question,
    val answer: Answer
)
