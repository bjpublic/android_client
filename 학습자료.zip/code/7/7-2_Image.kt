package online.dailyq.api.response

data class Image(val url: String)
