# from http import HTTPStatus
#
#
# class ApiException(Exception):
#     http_code = 500
#     message = None
#
#     def __init__(self, message=None):
#         self.message = message
#
#     def to_dict(self):
#         r = {}
#         if self.message:
#             r['message'] = self.message
#         else:
#             r['message'] = str(self.__class__.__name__)
#         return r
#
#
# # class UnknownException(ApiException):
# #     http_code = 500
#
# class BadRequest(ApiException):
#     http_code = 400
#
#
# class InvalidRefreshToken(ApiException):
#     http_code = 400
#
#
# class InvalidGrant(ApiException):
#     http_code = 401
#
#
# class Forbidden(ApiException):
#     http_code = 403
#
#
# class NotFound(ApiException):
#     http_code = 404
#
#
# class Conflict(ApiException):
#     http_code = 409
